package com.example.ubique_service_test;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;

import androidx.appcompat.app.AppCompatActivity;

public class seviceConnectActivity extends AppCompatActivity {
    public MyService myService;
    public boolean isService = false;
    public MakeJson makeJson = new MakeJson();

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(isService){
            unbindService(conn); // 서비스 종료
            isService = false;
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
    }
    ServiceConnection conn = new ServiceConnection() {
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            // 서비스와 연결되었을 때 호출되는 메서드
            // 서비스 객체를 전역변수로 저장
            MyService.MyBinder mb = (MyService.MyBinder) service;
            myService = mb.getService(); // 서비스가 제공하는 메소드 호출하여
            // 서비스쪽 객체를 전달받을수 있슴
            isService = true;
            //Toast.makeText(getApplicationContext(),"서비스 연결",Toast.LENGTH_LONG).show();
        }
        public void onServiceDisconnected(ComponentName name) {
            // 서비스와 연결이 끊겼을 때 호출되는 메서드
            isService = false;
            //Toast.makeText(getApplicationContext(), "서비스 연결 해제", Toast.LENGTH_LONG).show();
        }
    };
    public void serviceBind(Context contexts, boolean newConnection){
        Intent intent = new Intent(
                contexts, // 현재 화면
                MyService.class); // 다음넘어갈 컴퍼넌트

        if(newConnection){
            bindService(intent, // intent 객체
                    conn, // 서비스와 연결에 대한 정의
                    Context.BIND_AUTO_CREATE);
        }
        else{
            bindService(intent, // intent 객체
                    conn, // 서비스와 연결에 대한 정의
                    Context.BIND_NOT_FOREGROUND);
        }
        //처음 서비스를 시작하는 액티비티에서는 Context.BIND_AUTO_CREATE
        //다른 액티비티에서는 Context.BIND_NOT_FOREGROUND를 주어야합니다.
    }

}
